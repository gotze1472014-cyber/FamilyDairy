package com.example.familieladen

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
